Bonjour madame Jimena,

Suite à mon précédent e-mail, veuillez trouver ci-après le lien vers le commit apportant une correction au problème identifié par vos équipes.

Il s'agit du commit [bcdfa1c](https://github.com/GuillaumeOj/P11-AddAFeature/commit/bcdfa1c8fdc8899b7c06f3e469ffb28baee7f1ae). Les corrections sont les suivantes :

- utilisation d'une base de données PostgreSQL pour lancer les tests en local;
- suppression de validateurs inutiles sur certains champs des modèles `Category` et `Product`;
- correction des tests associés aux modèles précédents.

Cordialement,

Guillaume OJARDIAS.
